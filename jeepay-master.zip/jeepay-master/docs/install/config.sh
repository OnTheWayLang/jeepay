#! /bin/sh
#exec 2>>build.log  ##编译过程打印到日志文件中
## 配置文件   .Power by terrfly

# 【项目根目录的地址】 该地址下会包含： nginx/mysql/mq/redis等文件
rootDir="/jeepayhomes"

# 【mysql密码】建议更改
mysql_pwd="jeepaydb123456"


#当前路径， 不要更改参数。
currentPath=`pwd`













